function [fileImportName] = generateMatFile( selectFeaturesNr, selectPersonNr)

% Gestures numeration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x 00 - Reference noise 
% x 01 - Moutz power
% x 02 - A clenched fistZaci�ni�ta pi��, kciuk na zewn�trz
%   03 - Gest OK
%   04 - Pointing  - palec wskazuj�cy
% c 05 - Thumbs up - kciuk w g�r�
%   06 - Call me   - s�uchawka
%   07 - �apwica
%   08 - Otwieranie d�oni
%   09 - Zginanie palc�w po kolei
%   10 - trzymanie przedmiotu
% z 11 - Victoria - statyczne
%   12 - odlicznie - dynamiczne
% z 13 - Three middle fingers closer - 3 palce �rodkowe  statyczne
%   14 - moc - dynamiczne
%   15 - pi��-dynamiczne
%   16 - victoria dynamiczne
%   17 - 3 �rodkowe palce razem - dynamiczne
% c 18 - serdeczny palec w �rodek d�oni (like Spiderman)
%   19 - malypalec

% selectFeaturesNr = []; selectPersonNumber = []; % default all data

folder = '.\data\';  
dataSource = fullfile(folder, '*.wav'); 
file = dir(dataSource);

rawData = [];      % featVectBion matrix 
labelsVector = []; % Vertical vector gesture numbers
labelsMatrix = []; % Binary matrix

for fileNo = 1:length(file)
    s = file(fileNo).name
    
    tempPersonNumber = str2double(s(3:5));  % personNumber 
    if( length(selectPersonNr) )
        if( selectPersonNr ~= tempPersonNumber ) continue; end 
    end
    
    tempGestureNumber = str2double(s(1:2)); % gestureNumber 
    if( length(tempGestureNumber))
        if( selectFeaturesNr ~= tempGestureNumber ) continue; end % pomijaj wy�sze numery gestu i referencyjny   
    end
    
    labelsVector = [labelsVector; tempGestureNumber];
    s = strcat(file(fileNo).folder,'\');
    s = strcat(s,file(fileNo).name);    
    
    tempData = featvect(s);
%     figure(tempGestureNumber+1), plot(tempData); hold on; title(file(fileNo).name);
%     figure(2*tempGestureNumber+3), plot(audioread(s)); hold on;title(file(fileNo).name);
%     legend; figure(tempPersonNumber);plot(audioread(s));
    rawData = [rawData; tempData]; %dodanie info o nr gestu
end

dimX = length(labelsVector);
dimY = length(unique(labelsVector));
labelsMatrix = zeros( dimY, dimX ); 

feature = unique(labelsVector);

for i = 1:dimY    
    for k = 1:dimX
        if ( feature(i) == labelsVector(k) )
            labelsMatrix(i,k) = 1;     
        end
    end
end

featureCountDistribution = histcounts(labelsVector)
if( sum(diff( featureCountDistribution )) ~= 0 )
    warning("Check importData settings. Irregular distribution of features");    
    histogram(labelsVector); title('Imported data by gestureNr distribution');
end
 
clear folder file fileNo s tempGestureNumber tempData tempPersonNumber featureCountDistribution i k dimY dimX
% dataGeneratedAt = datestr(datetime('now'));
fileImportName = sprintf('dataEMGunique%dgesture.mat', length(unique(labelsVector))); % Count of qnique gestures labels
save(fileImportName);

end
