function STD=jSTD(X)
STD=std(X);
end